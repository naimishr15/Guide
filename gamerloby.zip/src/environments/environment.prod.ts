export const environment = {
  production: true,
  api: "https://gamerlobby.herokuapp.com/"
};
