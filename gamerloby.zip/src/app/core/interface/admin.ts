/**
 * Admin interface
 */
export interface IAdmin {
  username: string;
  password: string;
}
